from flask import Flask, render_template, redirect, url_for, request, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import requests

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobportal.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=False, unique=True)
    password = db.Column(db.String(150), nullable=False)
    role = db.Column(db.String(50), nullable=False)

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    description = db.Column(db.Text)
    salary = db.Column(db.String(100))
    location = db.Column(db.String(100))
    company = db.Column(db.String(100))
    employer_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

@app.route('/')
def home():
    jobs = Job.query.all()
    external_jobs = []
    try:
        response = requests.get("https://remoteok.com/api")  # Public job board (example)
        if response.status_code == 200:
            external_jobs = response.json()[1:6]  # Get a few public listings
    except:
        external_jobs = []
    return render_template('index.html', jobs=jobs, external_jobs=external_jobs)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        role = request.form['role']
        user = User(username=username, password=password, role=role)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'role' not in session:
        return redirect(url_for('login'))
    if session['role'] == 'employer':
        jobs = Job.query.filter_by(employer_id=session['user_id']).all()
        return render_template('employer_dashboard.html', jobs=jobs)
    elif session['role'] == 'jobseeker':
        jobs = Job.query.all()
        return render_template('jobseeker_dashboard.html', jobs=jobs)
    elif session['role'] == 'admin':
        users = User.query.all()
        jobs = Job.query.all()
        return render_template('admin_dashboard.html', users=users, jobs=jobs)

@app.route('/postjob', methods=['GET', 'POST'])
def postjob():
    if request.method == 'POST':
        job = Job(
            title=request.form['title'],
            description=request.form['description'],
            salary=request.form['salary'],
            location=request.form['location'],
            company=request.form['company'],
            employer_id=session['user_id']
        )
        db.session.add(job)
        db.session.commit()
        return redirect(url_for('dashboard'))
    return render_template('postjob.html')

@app.route('/apply/<int:job_id>')
def apply(job_id):
    if 'user_id' in session and session['role'] == 'jobseeker':
        application = Application(user_id=session['user_id'], job_id=job_id)
        db.session.add(application)
        db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
